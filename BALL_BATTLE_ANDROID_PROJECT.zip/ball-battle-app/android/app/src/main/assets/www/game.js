// BALL BATTLE: MESSI vs RONALDO
// Complete High-Performance Physics Game Engine

(function () {
  'use strict';

  // --- GAME CONSTANTS & STATE ---
  const STATES = {
    IDLE: 'IDLE',
    RUNNING: 'RUNNING',
    PAUSED: 'PAUSED',
    GAMEOVER: 'GAMEOVER'
  };

  let gameState = STATES.IDLE;
  let messiScore = 0;
  let ronaldoScore = 0;
  let roundDuration = 60; // 60 seconds
  let timeRemaining = 60;
  let lastTimestamp = 0;
  let timerAccumulator = 0;
  let totalBallsCount = 20; // 10 Messi (Pink), 10 Ronaldo (Yellow)

  // DOM Elements
  const canvas = document.getElementById('battleCanvas');
  const ctx = canvas.getContext('2d');
  const confettiCanvas = document.getElementById('confettiCanvas');
  const confettiCtx = confettiCanvas.getContext('2d');
  const canvasContainer = document.getElementById('canvasContainer');
  const floatNoticeContainer = document.getElementById('floatNoticeContainer');

  const messiCard = document.getElementById('messiCard');
  const ronaldoCard = document.getElementById('ronaldoCard');
  const messiScoreText = document.getElementById('messiScoreText');
  const ronaldoScoreText = document.getElementById('ronaldoScoreText');
  const timerText = document.getElementById('timerText');
  const timerBox = document.getElementById('timerBox');

  const startBattleBtn = document.getElementById('startBattleBtn');
  const startBtnLabel = document.getElementById('startBtnLabel');
  const startBtnIcon = document.getElementById('startBtnIcon');
  const pauseBattleBtn = document.getElementById('pauseBattleBtn');
  const pauseBtnLabel = document.getElementById('pauseBtnLabel');
  const resetBattleBtn = document.getElementById('resetBattleBtn');
  const shakeArenaBtn = document.getElementById('shakeArenaBtn');
  const soundToggleBtn = document.getElementById('soundToggleBtn');

  const startScreenModal = document.getElementById('startScreenModal');
  const modalStartBtn = document.getElementById('modalStartBtn');
  const winnerModal = document.getElementById('winnerModal');
  const winnerTitle = document.getElementById('winnerTitle');
  const winnerSubText = document.getElementById('winnerSubText');
  const winnerTrophyIcon = document.getElementById('winnerTrophyIcon');
  const winMessiFinal = document.getElementById('winMessiFinal');
  const winRonaldoFinal = document.getElementById('winRonaldoFinal');
  const rematchBtn = document.getElementById('rematchBtn');

  // --- ARENA GEOMETRY ---
  let dpr = window.devicePixelRatio || 1;
  let arena = {
    cx: 0,
    cy: 0,
    r: 150,
    gateAngleWidth: 0.38, // radians width of opening at bottom
    gateX1: 0,
    gateX2: 0,
    gateY: 0,
    pocketX: 0,
    pocketY: 0,
    pocketRadius: 28,
    pocketFunnelLeft: [],
    pocketFunnelRight: []
  };

  // --- ENTITIES ---
  let balls = [];
  let bumpers = [];
  let particles = [];
  let confettiParticles = [];
  let shockwaves = [];

  // Bumper definition inside the arena
  function initBumpers() {
    bumpers = [
      { relX: 0, relY: -0.22, r: 16, pulse: 0, color: '#00e5ff' },
      { relX: -0.42, relY: 0.12, r: 14, pulse: 0, color: '#ff007f' },
      { relX: 0.42, relY: 0.12, r: 14, pulse: 0, color: '#ffd000' },
      { relX: 0, relY: 0.42, r: 15, pulse: 0, color: '#00e5ff' }
    ];
  }

  // --- BALL CLASS ---
  class Ball {
    constructor(type, x, y, vx, vy) {
      this.type = type; // 'pink' (Messi) or 'yellow' (Ronaldo)
      this.number = type === 'pink' ? '10' : '7';
      this.color = type === 'pink' ? '#ff007f' : '#ffd000';
      this.glowColor = type === 'pink' ? 'rgba(255, 0, 127, 0.6)' : 'rgba(255, 208, 0, 0.6)';
      this.accentColor = type === 'pink' ? '#ffffff' : '#111827';
      this.x = x;
      this.y = y;
      this.vx = vx;
      this.vy = vy;
      this.r = 13.5;
      this.mass = 1;
      this.trails = [];
      this.maxTrail = 6;
      this.isEnteringPocket = false;
      this.pocketTimer = 0;
      this.opacity = 1;
      this.scale = 1;
    }

    update(dt) {
      if (this.isEnteringPocket) {
        // Suction towards center of pocket
        const dx = arena.pocketX - this.x;
        const dy = arena.pocketY - this.y;
        this.x += dx * 0.18;
        this.y += dy * 0.18;
        this.scale = Math.max(0, this.scale - 0.08);
        this.opacity = Math.max(0, this.opacity - 0.08);
        this.pocketTimer += dt;
        return;
      }

      // Record trail
      this.trails.push({ x: this.x, y: this.y });
      if (this.trails.length > this.maxTrail) {
        this.trails.shift();
      }

      // Downward gravity
      const gravity = 160; // px/s^2
      this.vy += gravity * dt;

      // Chaos jitter (keeps balls lively and bouncy)
      this.vx += (Math.random() - 0.5) * 6 * dt;
      this.vy += (Math.random() - 0.5) * 6 * dt;

      // Damping / terminal velocity
      const maxSpeed = 420;
      const speed = Math.hypot(this.vx, this.vy);
      if (speed > maxSpeed) {
        this.vx = (this.vx / speed) * maxSpeed;
        this.vy = (this.vy / speed) * maxSpeed;
      }

      // Movement
      this.x += this.vx * dt;
      this.y += this.vy * dt;
    }

    draw(ctx) {
      if (this.opacity <= 0) return;

      ctx.save();
      ctx.globalAlpha = this.opacity;

      // Draw glowing trail
      if (this.trails.length > 1 && !this.isEnteringPocket) {
        ctx.beginPath();
        ctx.moveTo(this.trails[0].x, this.trails[0].y);
        for (let i = 1; i < this.trails.length; i++) {
          ctx.lineTo(this.trails[i].x, this.trails[i].y);
        }
        ctx.strokeStyle = this.glowColor;
        ctx.lineWidth = this.r * 0.9 * this.scale;
        ctx.lineCap = 'round';
        ctx.globalAlpha = this.opacity * 0.35;
        ctx.stroke();
      }

      ctx.globalAlpha = this.opacity;

      // Ball Outer Glow
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r * this.scale, 0, Math.PI * 2);
      ctx.fillStyle = this.color;
      ctx.shadowColor = this.color;
      ctx.shadowBlur = 12;
      ctx.fill();

      // Ball 3D Gradient Sphere shading
      const grad = ctx.createRadialGradient(
        this.x - this.r * 0.35 * this.scale,
        this.y - this.r * 0.35 * this.scale,
        this.r * 0.15 * this.scale,
        this.x,
        this.y,
        this.r * this.scale
      );
      grad.addColorStop(0, '#ffffff');
      grad.addColorStop(0.35, this.color);
      grad.addColorStop(1, '#05060a');

      ctx.shadowBlur = 0;
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r * this.scale, 0, Math.PI * 2);
      ctx.fill();

      // Ball Inner Player Number (10 or 7)
      if (this.scale > 0.6) {
        ctx.fillStyle = this.accentColor;
        ctx.font = `900 ${Math.round(11 * this.scale)}px 'Orbitron', sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(this.number, this.x, this.y + 0.5);
      }

      ctx.restore();
    }
  }

  // --- PARTICLE SYSTEMS ---
  class Particle {
    constructor(x, y, color, speed = 150) {
      this.x = x;
      this.y = y;
      const angle = Math.random() * Math.PI * 2;
      const spd = (Math.random() * 0.8 + 0.2) * speed;
      this.vx = Math.cos(angle) * spd;
      this.vy = Math.sin(angle) * spd;
      this.color = color;
      this.r = Math.random() * 3 + 2;
      this.alpha = 1;
      this.decay = Math.random() * 1.5 + 1.2;
    }

    update(dt) {
      this.x += this.vx * dt;
      this.y += this.vy * dt;
      this.alpha -= this.decay * dt;
    }

    draw(ctx) {
      if (this.alpha <= 0) return;
      ctx.save();
      ctx.globalAlpha = Math.max(0, this.alpha);
      ctx.fillStyle = this.color;
      ctx.shadowColor = this.color;
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  // Winner Confetti
  class Confetti {
    constructor(w, h) {
      this.w = w;
      this.h = h;
      this.x = Math.random() * w;
      this.y = -20 - Math.random() * 100;
      this.vx = (Math.random() - 0.5) * 80;
      this.vy = Math.random() * 180 + 120;
      this.rotation = Math.random() * 360;
      this.vRot = (Math.random() - 0.5) * 360;
      this.size = Math.random() * 8 + 6;
      const colors = ['#ff007f', '#ffd000', '#00f0ff', '#ffffff', '#a855f7'];
      this.color = colors[Math.floor(Math.random() * colors.length)];
    }

    update(dt) {
      this.x += this.vx * dt;
      this.y += this.vy * dt;
      this.rotation += this.vRot * dt;
      if (this.y > this.h + 20) {
        this.y = -20;
        this.x = Math.random() * this.w;
      }
    }

    draw(ctx) {
      ctx.save();
      ctx.translate(this.x, this.y);
      ctx.rotate((this.rotation * Math.PI) / 180);
      ctx.fillStyle = this.color;
      ctx.fillRect(-this.size / 2, -this.size / 4, this.size, this.size / 2);
      ctx.restore();
    }
  }

  // --- INITIALIZATION & RESIZING ---
  function resizeCanvas() {
    const rect = canvasContainer.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    confettiCanvas.width = width * dpr;
    confettiCanvas.height = height * dpr;
    confettiCtx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // Compute Arena dimensions
    const arenaRadius = Math.min(width * 0.44, height * 0.36);
    arena.cx = width / 2;
    arena.cy = height * 0.40;
    arena.r = arenaRadius;

    // Bottom gate & pocket
    const halfOpening = arena.r * 0.32; // gate opening half-width
    arena.gateX1 = arena.cx - halfOpening;
    arena.gateX2 = arena.cx + halfOpening;
    arena.gateY = arena.cy + Math.sqrt(arena.r * arena.r - halfOpening * halfOpening);

    arena.pocketX = arena.cx;
    arena.pocketY = arena.cy + arena.r + 42;
    arena.pocketRadius = Math.max(26, arena.r * 0.2);

    // Funnel guiding walls from circular gate to pocket
    arena.pocketFunnelLeft = [
      { x: arena.gateX1, y: arena.gateY },
      { x: arena.pocketX - arena.pocketRadius * 0.9, y: arena.pocketY - 4 }
    ];
    arena.pocketFunnelRight = [
      { x: arena.gateX2, y: arena.gateY },
      { x: arena.pocketX + arena.pocketRadius * 0.9, y: arena.pocketY - 4 }
    ];

    initBumpers();
  }

  // Populate balls in the arena
  function spawnBalls(count) {
    balls = [];
    const half = Math.floor(count / 2);
    const types = [];
    for (let i = 0; i < half; i++) types.push('pink');
    for (let i = 0; i < half; i++) types.push('yellow');
    // Shuffle
    types.sort(() => Math.random() - 0.5);

    types.forEach((type, idx) => {
      // Spawn within top 65% of the arena to avoid instant scoring
      const angle = (idx / types.length) * Math.PI * 1.6 + 0.2 * Math.PI;
      const dist = (Math.random() * 0.6 + 0.15) * (arena.r - 25);
      const x = arena.cx + Math.cos(angle) * dist;
      const y = arena.cy + Math.sin(angle) * dist;
      const speed = Math.random() * 120 + 80;
      const moveAngle = Math.random() * Math.PI * 2;
      const vx = Math.cos(moveAngle) * speed;
      const vy = Math.sin(moveAngle) * speed;

      balls.push(new Ball(type, x, y, vx, vy));
    });
  }

  // Respawns a single ball at top after scoring
  function respawnBall(type) {
    // Drop from top funnel / portal with exciting downward velocity
    const spawnX = arena.cx + (Math.random() - 0.5) * (arena.r * 0.5);
    const spawnY = arena.cy - arena.r + 25;
    const speed = Math.random() * 140 + 100;
    const angle = (Math.random() * 0.8 + 0.1) * Math.PI; // downwards
    const vx = Math.cos(angle) * speed;
    const vy = Math.sin(angle) * speed + 50;

    const newBall = new Ball(type, spawnX, spawnY, vx, vy);
    balls.push(newBall);

    // Spawn mini particle ring at top
    for (let i = 0; i < 10; i++) {
      particles.push(new Particle(spawnX, spawnY, type === 'pink' ? '#ff007f' : '#ffd000', 90));
    }
  }

  // --- COLLISION RESOLUTION ---
  function resolveWallAndFunnelCollisions(ball) {
    if (ball.isEnteringPocket) return;

    // Check if ball has passed below gate into pocket funnel
    if (ball.y >= arena.gateY - 2) {
      // Check left funnel guide wall
      const fL1 = arena.pocketFunnelLeft[0];
      const fL2 = arena.pocketFunnelLeft[1];
      const distL = pointToSegmentDistance(ball.x, ball.y, fL1.x, fL1.y, fL2.x, fL2.y);
      if (distL.dist < ball.r) {
        ball.x += distL.nx * (ball.r - distL.dist);
        ball.y += distL.ny * (ball.r - distL.dist);
        reflectVelocity(ball, distL.nx, distL.ny, 0.85);
      }

      // Check right funnel guide wall
      const fR1 = arena.pocketFunnelRight[0];
      const fR2 = arena.pocketFunnelRight[1];
      const distR = pointToSegmentDistance(ball.x, ball.y, fR1.x, fR1.y, fR2.x, fR2.y);
      if (distR.dist < ball.r) {
        ball.x += distR.nx * (ball.r - distR.dist);
        ball.y += distR.ny * (ball.r - distR.dist);
        reflectVelocity(ball, distR.nx, distR.ny, 0.85);
      }

      // Check pocket entry trigger!
      const distToPocket = Math.hypot(ball.x - arena.pocketX, ball.y - arena.pocketY);
      if (distToPocket < arena.pocketRadius * 0.95 || ball.y > arena.pocketY - 10) {
        triggerPocketGoal(ball);
        return;
      }
    } else {
      // Inside main circular arena
      const dx = ball.x - arena.cx;
      const dy = ball.y - arena.cy;
      const dist = Math.hypot(dx, dy);

      // Check if near bottom gate opening
      const isOverGate = (ball.x > arena.gateX1 && ball.x < arena.gateX2 && ball.y > arena.cy);

      if (!isOverGate) {
        // Collide against circular perimeter
        if (dist + ball.r > arena.r) {
          const nx = dx / (dist || 1);
          const ny = dy / (dist || 1);

          ball.x = arena.cx + nx * (arena.r - ball.r);
          ball.y = arena.cy + ny * (arena.r - ball.r);

          reflectVelocity(ball, -nx, -ny, 0.92);

          if (Math.hypot(ball.vx, ball.vy) > 80 && Math.random() < 0.35) {
            window.soundController.playBounce(Math.hypot(ball.vx, ball.vy) / 20, true);
          }
        }
      }
    }
  }

  function reflectVelocity(ball, nx, ny, restitution) {
    const dot = ball.vx * nx + ball.vy * ny;
    if (dot < 0) {
      ball.vx -= (1 + restitution) * dot * nx;
      ball.vy -= (1 + restitution) * dot * ny;
    }
  }

  function pointToSegmentDistance(px, py, x1, y1, x2, y2) {
    const l2 = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);
    if (l2 === 0) return { dist: Math.hypot(px - x1, py - y1), nx: 0, ny: 0 };
    let t = ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / l2;
    t = Math.max(0, Math.min(1, t));
    const projX = x1 + t * (x2 - x1);
    const projY = y1 + t * (y2 - y1);
    const dx = px - projX;
    const dy = py - projY;
    const d = Math.hypot(dx, dy);
    return { dist: d, nx: dx / (d || 1), ny: dy / (d || 1) };
  }

  // Check collision between balls
  function resolveBallBallCollisions() {
    for (let i = 0; i < balls.length; i++) {
      const b1 = balls[i];
      if (b1.isEnteringPocket) continue;

      for (let j = i + 1; j < balls.length; j++) {
        const b2 = balls[j];
        if (b2.isEnteringPocket) continue;

        const dx = b2.x - b1.x;
        const dy = b2.y - b1.y;
        const dist = Math.hypot(dx, dy);
        const minDist = b1.r + b2.r;

        if (dist < minDist && dist > 0.001) {
          // Positional overlap correction
          const overlap = minDist - dist;
          const nx = dx / dist;
          const ny = dy / dist;

          b1.x -= nx * overlap * 0.5;
          b1.y -= ny * overlap * 0.5;
          b2.x += nx * overlap * 0.5;
          b2.y += ny * overlap * 0.5;

          // Normal and Tangential impulse
          const rvx = b2.vx - b1.vx;
          const rvy = b2.vy - b1.vy;
          const velAlongNormal = rvx * nx + rvy * ny;

          if (velAlongNormal < 0) {
            const restitution = 0.95;
            const impulse = -(1 + restitution) * velAlongNormal / 2;

            b1.vx -= impulse * nx;
            b1.vy -= impulse * ny;
            b2.vx += impulse * nx;
            b2.vy += impulse * ny;

            // Occasional bounce sound
            if (Math.abs(velAlongNormal) > 120 && Math.random() < 0.4) {
              window.soundController.playBounce(Math.abs(velAlongNormal) / 15, false);
            }
          }
        }
      }
    }
  }

  // Check collision with Pinball Bumpers
  function resolveBumperCollisions() {
    bumpers.forEach(bm => {
      const bx = arena.cx + bm.relX * arena.r;
      const by = arena.cy + bm.relY * arena.r;

      balls.forEach(ball => {
        if (ball.isEnteringPocket) return;

        const dx = ball.x - bx;
        const dy = ball.y - by;
        const dist = Math.hypot(dx, dy);
        const minDist = ball.r + bm.r;

        if (dist < minDist && dist > 0.001) {
          const nx = dx / dist;
          const ny = dy / dist;

          ball.x = bx + nx * minDist;
          ball.y = by + ny * minDist;

          // Bumper super kick impulse!
          const kickSpeed = 260;
          ball.vx = nx * kickSpeed + (Math.random() - 0.5) * 80;
          ball.vy = ny * kickSpeed - 60; // extra upward bounce

          bm.pulse = 1; // visual bump
          window.soundController.playBounce(12, true);

          // Particles
          for (let p = 0; p < 5; p++) {
            particles.push(new Particle(bx + nx * bm.r, by + ny * bm.r, bm.color, 100));
          }
        }
      });
    });
  }

  // --- SCORING SYSTEM ---
  function triggerPocketGoal(ball) {
    if (ball.isEnteringPocket) return;
    ball.isEnteringPocket = true;

    if (ball.type === 'pink') {
      // MESSI SCORES!
      messiScore++;
      messiScoreText.textContent = messiScore;
      animateScoreBump(messiScoreText, messiCard, '#ff007f');
      showFloatNotice('+1 MESSI ⚽', '#ff007f', arena.pocketX, arena.pocketY - 20);
      window.soundController.playMessiGoal();
    } else {
      // RONALDO SCORES!
      ronaldoScore++;
      ronaldoScoreText.textContent = ronaldoScore;
      animateScoreBump(ronaldoScoreText, ronaldoCard, '#ffd000');
      showFloatNotice('+1 RONALDO ⚽', '#ffd000', arena.pocketX, arena.pocketY - 20);
      window.soundController.playRonaldoGoal();
    }

    // Goal explosion particles
    const pColor = ball.type === 'pink' ? '#ff007f' : '#ffd000';
    for (let i = 0; i < 28; i++) {
      particles.push(new Particle(arena.pocketX, arena.pocketY, pColor, 180));
    }

    // Respawn ball of same type at top after small delay
    setTimeout(() => {
      // Remove dead ball from array
      const idx = balls.indexOf(ball);
      if (idx !== -1) balls.splice(idx, 1);
      if (gameState !== STATES.GAMEOVER) {
        respawnBall(ball.type);
      }
    }, 280);
  }

  function animateScoreBump(scoreElem, cardElem, color) {
    scoreElem.classList.remove('score-bump');
    cardElem.classList.remove('active-score');
    void scoreElem.offsetWidth; // trigger reflow
    void cardElem.offsetWidth;
    scoreElem.classList.add('score-bump');
    cardElem.classList.add('active-score');
    setTimeout(() => {
      cardElem.classList.remove('active-score');
    }, 400);
  }

  function showFloatNotice(text, color, x, y) {
    const el = document.createElement('div');
    el.className = 'float-score-text';
    el.style.left = `${x}px`;
    el.style.top = `${y}px`;
    el.style.color = color;
    el.textContent = text;
    floatNoticeContainer.appendChild(el);
    setTimeout(() => {
      if (el.parentNode) el.parentNode.removeChild(el);
    }, 850);
  }

  // --- TURBO SHAKE ---
  function turboShake() {
    window.soundController.playTurbo();
    canvasContainer.classList.add('shake-anim');
    setTimeout(() => canvasContainer.classList.remove('shake-anim'), 400);

    // Blast all balls upwards and outwards
    balls.forEach(ball => {
      if (!ball.isEnteringPocket) {
        ball.vy = -(Math.random() * 260 + 160);
        ball.vx += (Math.random() - 0.5) * 320;
      }
    });

    // Particle burst
    for (let i = 0; i < 30; i++) {
      particles.push(new Particle(arena.cx, arena.cy, '#00f0ff', 240));
    }
  }

  // --- DRAWING ARENA & POCKET ---
  function drawArena(ctx) {
    ctx.save();

    // 1. Outer Arena Ring Shadow & Neon Glow
    ctx.beginPath();
    ctx.arc(arena.cx, arena.cy, arena.r, 0, Math.PI * 2);
    ctx.fillStyle = '#0a0d17';
    ctx.shadowColor = 'rgba(0, 240, 255, 0.4)';
    ctx.shadowBlur = 24;
    ctx.fill();
    ctx.shadowBlur = 0;

    // 2. Arena Internal Field Graphics (Stadium soccer center circle & neon grid)
    ctx.beginPath();
    ctx.arc(arena.cx, arena.cy, arena.r, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(15, 20, 34, 0.95)';
    ctx.fill();

    // Field Center Circle
    ctx.beginPath();
    ctx.arc(arena.cx, arena.cy, arena.r * 0.45, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.12)';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Field Center Line
    ctx.beginPath();
    ctx.moveTo(arena.cx - arena.r * 0.9, arena.cy);
    ctx.lineTo(arena.cx + arena.r * 0.9, arena.cy);
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.08)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // 3. Circular Arena Perimeter with bottom gate opening
    // We draw the arc from gateX2 to gateX1 (clockwise over the top)
    const angleRight = Math.atan2(arena.gateY - arena.cy, arena.gateX2 - arena.cx);
    const angleLeft = Math.atan2(arena.gateY - arena.cy, arena.gateX1 - arena.cx);

    ctx.beginPath();
    ctx.arc(arena.cx, arena.cy, arena.r, angleRight, angleLeft, false);
    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 4;
    ctx.shadowColor = '#00f0ff';
    ctx.shadowBlur = 15;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // 4. Funnel Walls leading to Pocket
    ctx.beginPath();
    ctx.moveTo(arena.pocketFunnelLeft[0].x, arena.pocketFunnelLeft[0].y);
    ctx.lineTo(arena.pocketFunnelLeft[1].x, arena.pocketFunnelLeft[1].y);
    ctx.strokeStyle = '#ff007f';
    ctx.lineWidth = 3.5;
    ctx.shadowColor = '#ff007f';
    ctx.shadowBlur = 10;
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(arena.pocketFunnelRight[0].x, arena.pocketFunnelRight[0].y);
    ctx.lineTo(arena.pocketFunnelRight[1].x, arena.pocketFunnelRight[1].y);
    ctx.strokeStyle = '#ffd000';
    ctx.lineWidth = 3.5;
    ctx.shadowColor = '#ffd000';
    ctx.shadowBlur = 10;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // 5. Point Pocket at the bottom (Vortex & Scoring Zone)
    drawPointPocket(ctx);

    // 6. Draw Pinball Bumpers
    drawBumpers(ctx);

    ctx.restore();
  }

  function drawPointPocket(ctx) {
    const px = arena.pocketX;
    const py = arena.pocketY;
    const pr = arena.pocketRadius;

    ctx.save();

    // Outer glow ring
    ctx.beginPath();
    ctx.arc(px, py, pr, 0, Math.PI * 2);
    ctx.fillStyle = '#05070c';
    ctx.shadowColor = '#00f0ff';
    ctx.shadowBlur = 20;
    ctx.fill();

    // Pocket border with neon cyan / gradient
    ctx.lineWidth = 3;
    const pocketGrad = ctx.createLinearGradient(px - pr, py, px + pr, py);
    pocketGrad.addColorStop(0, '#ff007f');
    pocketGrad.addColorStop(0.5, '#00f0ff');
    pocketGrad.addColorStop(1, '#ffd000');
    ctx.strokeStyle = pocketGrad;
    ctx.stroke();

    // Vortex swirling concentric rings
    const time = Date.now() * 0.003;
    for (let i = 1; i <= 3; i++) {
      ctx.beginPath();
      const rRing = pr * (i / 3.5);
      ctx.arc(px, py, rRing, time * (i % 2 === 0 ? 1 : -1), time * (i % 2 === 0 ? 1 : -1) + Math.PI * 1.4);
      ctx.strokeStyle = i === 1 ? '#00f0ff' : (i === 2 ? '#ff007f' : '#ffd000');
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }

    // Directional arrows pointing down into pocket
    const arrowY = arena.gateY + (py - arena.gateY) * 0.35;
    ctx.fillStyle = '#00f0ff';
    ctx.font = '900 13px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = '#00f0ff';
    ctx.shadowBlur = 8;
    ctx.fillText('▼ GOAL POCKET ▼', px, arrowY);

    ctx.restore();
  }

  function drawBumpers(ctx) {
    bumpers.forEach(bm => {
      const bx = arena.cx + bm.relX * arena.r;
      const by = arena.cy + bm.relY * arena.r;

      ctx.save();
      // Decay pulse
      if (bm.pulse > 0) bm.pulse = Math.max(0, bm.pulse - 0.05);

      const r = bm.r + bm.pulse * 4;

      ctx.beginPath();
      ctx.arc(bx, by, r, 0, Math.PI * 2);
      ctx.fillStyle = '#111827';
      ctx.shadowColor = bm.color;
      ctx.shadowBlur = 10 + bm.pulse * 15;
      ctx.fill();

      ctx.beginPath();
      ctx.arc(bx, by, r, 0, Math.PI * 2);
      ctx.strokeStyle = bm.color;
      ctx.lineWidth = 2.5 + bm.pulse * 2;
      ctx.stroke();

      // Bumper inner core
      ctx.beginPath();
      ctx.arc(bx, by, r * 0.4, 0, Math.PI * 2);
      ctx.fillStyle = bm.color;
      ctx.fill();

      ctx.restore();
    });
  }

  // --- GAME LOOP & UPDATES ---
  function gameLoop(timestamp) {
    if (!lastTimestamp) lastTimestamp = timestamp;
    const dt = Math.min((timestamp - lastTimestamp) / 1000, 0.05);
    lastTimestamp = timestamp;

    // Timer logic if running
    if (gameState === STATES.RUNNING) {
      timerAccumulator += dt;
      if (timerAccumulator >= 1.0) {
        timerAccumulator -= 1.0;
        timeRemaining = Math.max(0, timeRemaining - 1);
        updateTimerDisplay();

        if (timeRemaining <= 0) {
          triggerGameOver();
        }
      }

      // Physics Updates
      balls.forEach(ball => {
        ball.update(dt);
        resolveWallAndFunnelCollisions(ball);
      });

      resolveBallBallCollisions();
      resolveBumperCollisions();
    }

    // Particle Updates
    for (let i = particles.length - 1; i >= 0; i--) {
      particles[i].update(dt);
      if (particles[i].alpha <= 0) particles.splice(i, 1);
    }

    // Confetti Updates if Game Over
    if (gameState === STATES.GAMEOVER) {
      confettiCtx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
      confettiParticles.forEach(c => {
        c.update(dt);
        c.draw(confettiCtx);
      });
    }

    // Render Canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawArena(ctx);
    balls.forEach(ball => ball.draw(ctx));
    particles.forEach(p => p.draw(ctx));

    requestAnimationFrame(gameLoop);
  }

  function updateTimerDisplay() {
    const mins = Math.floor(timeRemaining / 60);
    const secs = timeRemaining % 60;
    timerText.textContent = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

    if (timeRemaining <= 10) {
      timerBox.classList.add('timer-low');
    } else {
      timerBox.classList.remove('timer-low');
    }
  }

  // --- STATE CONTROLS ---
  function startBattle() {
    window.soundController.init();
    window.soundController.playWhistle();

    if (gameState === STATES.IDLE || gameState === STATES.GAMEOVER) {
      resetMatchData();
    }

    gameState = STATES.RUNNING;
    startScreenModal.classList.add('hidden');
    winnerModal.classList.add('hidden');

    startBattleBtn.classList.remove('state-paused');
    startBtnLabel.textContent = 'BATTLE RUNNING';
    startBtnIcon.textContent = '⚡';
    pauseBtnLabel.textContent = '⏸ PAUSE';
  }

  function pauseBattle() {
    window.soundController.playClick();
    if (gameState === STATES.RUNNING) {
      gameState = STATES.PAUSED;
      pauseBtnLabel.textContent = '▶ RESUME';
      startBattleBtn.classList.add('state-paused');
      startBtnLabel.textContent = 'RESUME BATTLE';
    } else if (gameState === STATES.PAUSED) {
      gameState = STATES.RUNNING;
      pauseBtnLabel.textContent = '⏸ PAUSE';
      startBattleBtn.classList.remove('state-paused');
      startBtnLabel.textContent = 'BATTLE RUNNING';
    }
  }

  function resetBattle() {
    window.soundController.playClick();
    resetMatchData();
    gameState = STATES.IDLE;
    startBattleBtn.classList.remove('state-paused');
    startBtnLabel.textContent = 'START BATTLE';
    startBtnIcon.textContent = '⚡';
    pauseBtnLabel.textContent = '⏸ PAUSE';
    winnerModal.classList.add('hidden');
  }

  function resetMatchData() {
    messiScore = 0;
    ronaldoScore = 0;
    timeRemaining = roundDuration;
    timerAccumulator = 0;
    messiScoreText.textContent = '0';
    ronaldoScoreText.textContent = '0';
    timerBox.classList.remove('timer-low');
    updateTimerDisplay();
    particles = [];
    confettiParticles = [];
    confettiCtx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
    floatNoticeContainer.innerHTML = '';
    spawnBalls(totalBallsCount);
  }

  function triggerGameOver() {
    gameState = STATES.GAMEOVER;
    window.soundController.playVictory();

    winMessiFinal.textContent = messiScore;
    winRonaldoFinal.textContent = ronaldoScore;

    if (messiScore > ronaldoScore) {
      winnerTrophyIcon.textContent = '🏆';
      winnerTitle.textContent = 'MESSI WINS!';
      winnerTitle.className = 'winner-champion-title messi-win';
      winnerSubText.textContent = `লিওনেল মেসি ${messiScore}-${ronaldoScore} গোলে চ্যাম্পিয়ন হয়েছেন!`;
    } else if (ronaldoScore > messiScore) {
      winnerTrophyIcon.textContent = '🏆';
      winnerTitle.textContent = 'RONALDO WINS!';
      winnerTitle.className = 'winner-champion-title ronaldo-win';
      winnerSubText.textContent = `ক্রিস্টিয়ানো রোনালদো ${ronaldoScore}-${messiScore} গোলে চ্যাম্পিয়ন হয়েছেন! SIUUU!`;
    } else {
      winnerTrophyIcon.textContent = '🤝';
      winnerTitle.textContent = 'EPIC DRAW!';
      winnerTitle.className = 'winner-champion-title draw-match';
      winnerSubText.textContent = `ম্যাচটি ${messiScore}-${ronaldoScore} সমতায় শেষ হয়েছে! অসাধারণ লড়াই!`;
    }

    // Spawn 80 confetti pieces
    confettiParticles = [];
    for (let i = 0; i < 80; i++) {
      confettiParticles.push(new Confetti(confettiCanvas.width / dpr, confettiCanvas.height / dpr));
    }

    winnerModal.classList.remove('hidden');
  }

  // --- EVENT LISTENERS ---
  function setupEventListeners() {
    window.addEventListener('resize', () => {
      resizeCanvas();
    });

    // Control buttons
    startBattleBtn.addEventListener('click', () => {
      if (gameState === STATES.PAUSED) {
        pauseBattle();
      } else {
        startBattle();
      }
    });

    pauseBattleBtn.addEventListener('click', () => {
      pauseBattle();
    });

    resetBattleBtn.addEventListener('click', () => {
      resetBattle();
    });

    modalStartBtn.addEventListener('click', () => {
      startBattle();
    });

    rematchBtn.addEventListener('click', () => {
      startBattle();
    });

    shakeArenaBtn.addEventListener('click', () => {
      turboShake();
    });

    soundToggleBtn.addEventListener('click', () => {
      window.soundController.init();
      const enabled = window.soundController.toggle();
      soundToggleBtn.textContent = enabled ? '🔊 SOUND' : '🔇 MUTED';
    });

    // Ball Count Options
    document.querySelectorAll('#ballCountSelector .pill-option').forEach(pill => {
      pill.addEventListener('click', () => {
        window.soundController.playClick();
        document.querySelectorAll('#ballCountSelector .pill-option').forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        totalBallsCount = parseInt(pill.dataset.count, 10);
        spawnBalls(totalBallsCount);
      });
    });

    // Interactive canvas tap impulse / ripple
    canvas.addEventListener('pointerdown', (e) => {
      window.soundController.init();
      const rect = canvas.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const clickY = e.clientY - rect.top;

      // Push nearby balls away with impulse
      balls.forEach(ball => {
        const dx = ball.x - clickX;
        const dy = ball.y - clickY;
        const dist = Math.hypot(dx, dy);
        if (dist < 100 && dist > 1) {
          const power = (1 - dist / 100) * 280;
          ball.vx += (dx / dist) * power;
          ball.vy += (dy / dist) * power;
        }
      });

      // Spawn tap ripple particles
      for (let i = 0; i < 8; i++) {
        particles.push(new Particle(clickX, clickY, '#00f0ff', 120));
      }
      window.soundController.playBounce(8, false);
    });
  }

  // --- START ENGINE ---
  window.addEventListener('DOMContentLoaded', () => {
    resizeCanvas();
    spawnBalls(totalBallsCount);
    setupEventListeners();
    requestAnimationFrame(gameLoop);
  });

})();
