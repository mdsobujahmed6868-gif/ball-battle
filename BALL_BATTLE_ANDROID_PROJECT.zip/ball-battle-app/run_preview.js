const { spawn } = require('child_process');
const fs = require('fs');
const http = require('http');

async function main() {
  console.log('Launching headless Chrome...');
  const chrome = spawn('google-chrome', [
    '--headless=new',
    '--no-sandbox',
    '--disable-gpu',
    '--remote-debugging-port=9222',
    '--window-size=480,854',
    'file:///workspace/ball-battle-app/index.html'
  ]);

  chrome.stderr.on('data', d => {});

  // Wait for remote debugging to be ready
  let targets = null;
  for (let i = 0; i < 20; i++) {
    await new Promise(r => setTimeout(r, 400));
    try {
      targets = await new Promise((resolve, reject) => {
        http.get('http://127.0.0.1:9222/json', res => {
          let data = '';
          res.on('data', chunk => (data += chunk));
          res.on('end', () => resolve(JSON.parse(data)));
        }).on('error', reject);
      });
      if (targets && targets.length > 0) break;
    } catch (e) {}
  }

  if (!targets || targets.length === 0) {
    console.error('Failed to connect to Chrome debugging target');
    chrome.kill();
    process.exit(1);
  }

  const page = targets.find(t => t.type === 'page') || targets[0];
  console.log('Connecting to DevTools WebSocket:', page.webSocketDebuggerUrl);

  const ws = new WebSocket(page.webSocketDebuggerUrl);
  let id = 1;
  const pending = new Map();

  ws.onmessage = msg => {
    const data = JSON.parse(msg.data);
    if (data.id && pending.has(data.id)) {
      pending.get(data.id)(data.result);
      pending.delete(data.id);
    }
  };

  await new Promise(r => (ws.onopen = r));

  function send(method, params = {}) {
    const curId = id++;
    return new Promise(resolve => {
      pending.set(curId, resolve);
      ws.send(JSON.stringify({ id: curId, method, params }));
    });
  }

  // Set viewport
  await send('Emulation.setDeviceMetricsOverride', {
    width: 480,
    height: 854,
    deviceScaleFactor: 2,
    mobile: true
  });

  // Capture helper
  async function takeScreenshot(filename) {
    const res = await send('Page.captureScreenshot', { format: 'png' });
    if (res && res.data) {
      fs.writeFileSync(filename, Buffer.from(res.data, 'base64'));
      console.log('Saved screenshot:', filename);
    }
  }

  // 1. Start Screen
  await new Promise(r => setTimeout(r, 600));
  await takeScreenshot('preview_01_start.png');

  // 2. Click Start Battle button
  console.log('Clicking START BATTLE button...');
  await send('Runtime.evaluate', {
    expression: `document.getElementById('modalStartBtn').click()`
  });

  // Let battle run for 3.5 seconds
  console.log('Battle simulation in progress (balls colliding & moving)...');
  await new Promise(r => setTimeout(r, 3500));
  await takeScreenshot('preview_02_battle_active.png');

  // Let balls score and simulate turbo shake
  console.log('Triggering TURBO SHAKE and capturing action...');
  await send('Runtime.evaluate', {
    expression: `document.getElementById('shakeArenaBtn').click()`
  });
  await new Promise(r => setTimeout(r, 1200));
  await takeScreenshot('preview_03_turbo_action.png');

  // Trigger Winner Celebration modal
  console.log('Triggering match conclusion and winner screen...');
  await send('Runtime.evaluate', {
    expression: `
      // End match to show winner screen
      document.getElementById('messiScoreText').textContent = '4';
      document.getElementById('ronaldoScoreText').textContent = '2';
      // Trigger game over celebration
      const evt = new CustomEvent('gameover');
      // Set winner modal visible
      document.getElementById('winMessiFinal').textContent = '4';
      document.getElementById('winRonaldoFinal').textContent = '2';
      document.getElementById('winnerTitle').textContent = 'MESSI WINS!';
      document.getElementById('winnerTitle').className = 'winner-champion-title messi-win';
      document.getElementById('winnerSubText').textContent = 'Lionel Messi wins 4-2! Champion!';
      document.getElementById('winnerModal').classList.remove('hidden');
    `
  });
  await new Promise(r => setTimeout(r, 500));
  await takeScreenshot('preview_04_winner_celebration.png');

  ws.close();
  chrome.kill();
  console.log('Done capturing preview screenshots!');
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
